  int drawcard();
//^^draw random cards
  int TOT(int cards[], int size);
//^^calculate total